//
// Created by Champrin on 2023/8/1.
//

#include "camera_stream/record/save_video.h"

#include "utils/rm_log.h"
#include "utils/file/file_operation.h"

namespace camera_stream {

SaveVideo::SaveVideo(const std::string &camera_name, const cv::Size2f &image_size, const GetImageFunc &get_image_func)
        : get_image_func_(get_image_func), is_loop_(true) {
    std::string path = "../vision_data/avi_save/" + camera_name + "/"; // 视频保存目录
    utils::FileOperation::CreateNewDirectory(path);
    save_video_name_ = path + std::to_string(utils::FileOperation::GetFileSizeInOrder(path, ".avi")) + ".avi"; // 视频保存文件名

    video_writer_uptr = std::make_unique<cv::VideoWriter>(
            save_video_name_, cv::VideoWriter::fourcc('X', 'V', 'I', 'D'), 16, image_size);
    save_video_thread_ = std::thread([this]() {
        RM_LOG_INFO("start save avi to {}" + save_video_name_);
        while (is_loop_) {
            video_writer_uptr->write(get_image_func_().image);
        }
        if (video_writer_uptr != nullptr) {
            video_writer_uptr->release();
        }
    });
}

void SaveVideo::Destroy() {
    is_loop_ = false;
    save_video_thread_.join();
    RM_LOG_INFO("Finish avi to {}" + save_video_name_);
}

}