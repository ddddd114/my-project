//
// Created by champrin on 9/7/25.
//

#include "camera_stream/daheng_camera_stream.h"

#include <csignal>

namespace camera_stream {

#define ACQ_BUFFER_NUM          5               ///< Acquisition Buffer Qty.
#define ACQ_TRANSFER_SIZE       (64 * 1024)     ///< Size of data transfer block
#define ACQ_TRANSFER_NUMBER_URB 64              ///< Qty. of data transfer block
#define FILE_NAME_LEN           50              ///< Save image file name length

#define PIXFMT_CVT_FAIL             -1             ///< PixelFormatConvert fail
#define PIXFMT_CVT_SUCCESS          0              ///< PixelFormatConvert success

//----------------------------------------------------------------------------------
/**
\brief  Get description of input error code
\param  emErrorStatus  error code

\return void
*/
//----------------------------------------------------------------------------------
std::string GetErrorString(GX_STATUS emErrorStatus) {
    char *error_info = NULL;
    size_t size = 0;
    GX_STATUS emStatus = GX_STATUS_SUCCESS;

    // Get length of error description
    emStatus = GXGetLastError(&emErrorStatus, NULL, &size);
    if (emStatus != GX_STATUS_SUCCESS) {
        return "<Error when calling GXGetLastError>";
    }

    // Alloc error resources
    error_info = new char[size];
    if (error_info == nullptr) {
        return "<Failed to allocate memory>";
    }

    // Get error description
    emStatus = GXGetLastError(&emErrorStatus, error_info, &size);
    std::string error_string = {error_info};
    if (emStatus != GX_STATUS_SUCCESS) {
        error_string = "<Error when calling GXGetLastError>";
    } else {
    }

    // Realease error resources
    if (error_info != nullptr) {
        delete[]error_info;
        error_info = NULL;
    }

    return error_string;
}

DaHengCameraStream::DaHengCameraStream(const std::string &serial_number) : CameraStream(serial_number) {

    //Initialize libary
    emStatus = GXInitLib();
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_INFO("{0} connectCamera-> error InitLib, {1}", serial_number_prefix_, GetErrorString(emStatus));
        return;
    }

    // 发现相机
    DiscoverCamera(serial_number);

    // 设置相机参数
    GX_INT_VALUE limit_node; // 取得相机分辨率的 height 属性节点
    memset(&limit_node, 0, sizeof(GX_INT_VALUE));
    GXGetIntValue(g_hDevice, "DeviceLinkThroughputLimit", &limit_node);
    emStatus = GXSetIntValue(g_hDevice, "DeviceLinkThroughputLimit", limit_node.nMax); // 带宽限制拉到最大，使帧率拉满
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("{0} DeviceLinkThroughputLimit Set Continue fail! nRet {1:x}", serial_number_prefix_,
                     (unsigned int) emStatus);
        RM_LOG_ERROR("error string: {0}", GetErrorString(emStatus));
        raise(SIGUSR1);
    }

    SetADCBitDepth(8); // 设置景深
    SetAcquisitionFrameRate(250.0); // 设置相机最大帧率
    SetExposureMode(OFF); // 关闭相机内部的自动曝光
    SetBalanceWhiteMode(CONTINUOUS); // 打开自动白平衡
    RM_LOG_INFO("{0} connectCamera-> modify camera init successful.", serial_number_prefix_);

    // 连接相机
    ConnectCamera();

    // 设置图像参数
    GX_INT_VALUE height_node; // 取得相机分辨率的 height 属性节点
    memset(&height_node, 0, sizeof(GX_INT_VALUE));
    GXGetIntValue(g_hDevice, "Height", &height_node);

    GX_INT_VALUE width_node; // 取得相机分辨率的 width 属性节点
    memset(&width_node, 0, sizeof(GX_INT_VALUE));
    GXGetIntValue(g_hDevice, "Width", &width_node);

    mat_image_.image = cv::Mat(static_cast<int>(height_node.nCurValue), static_cast<int>(width_node.nCurValue),
                               CV_8UC3);
    mat_size_ = {static_cast<float>(width_node.nCurValue), static_cast<float>(height_node.nCurValue)};

    height_ = static_cast<unsigned short>(height_node.nCurValue);
    width_ = static_cast<unsigned short>(width_node.nCurValue);

    // 开始拉流线程
    Start();
    std::this_thread::sleep_for(std::chrono::milliseconds(800));

    RM_LOG_INFO("{0} connectCamera-> calculate ready.", serial_number_prefix_);
}

void DaHengCameraStream::DiscoverCamera(const std::string &serial_number) {
    // 打开设备
    uint32_t ui32DeviceNum = 0;

    int loop_cnt = 0;
    bool is_find = false;
    while (!is_find) {
        if (loop_cnt >= 25) {
            raise(SIGUSR1);
        }
        ui32DeviceNum = 0;
        emStatus = GXUpdateAllDeviceList(&ui32DeviceNum, 1000); // 枚举设备
        if (emStatus != GX_STATUS_SUCCESS) { // 发现设备失败
            RM_LOG_ERROR("{0} discoverCamera-> discover device fail, continue find camera device...",
                         serial_number_prefix_);
            RM_LOG_ERROR("discoverCamera-> error string: {0}", GetErrorString(emStatus));
            ++loop_cnt;
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }

        if (ui32DeviceNum <= 0) { // 相机设备为空
            RM_LOG_ERROR("{0} discoverCamera-> no camera device find, continue find camera device...",
                         serial_number_prefix_);
            ++loop_cnt;
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }

        GX_DEVICE_INFO device_info_ptr;
        memset(&device_info_ptr, 0, sizeof(GX_DEVICE_INFO));
        for (uint32_t i = 1; i <= ui32DeviceNum; ++i) { // 设备序号，从1开始，例如：1、2、3、4...
            emStatus = GXGetDeviceInfo(i, &device_info_ptr); // 枚举设备

            // TODO 以下只涉及GX_DEVICE_CLASS_U3V相机，其他类型的相机没有涉及

            if (emStatus != GX_STATUS_SUCCESS) {
                RM_LOG_ERROR("{0} discoverCamera-> index: {1} GXGetDeviceInfo fail", serial_number_prefix_,
                             static_cast<int>(i));
                RM_LOG_ERROR("discoverCamera-> error string: {0}", GetErrorString(emStatus));
                continue;
            }

            if (device_info_ptr.emDevType != GX_DEVICE_CLASS_U3V) {
                RM_LOG_ERROR("{0} discoverCamera-> index: {1} DevType != GX_DEVICE_CLASS_U3V", serial_number_prefix_,
                             static_cast<int>(i));
                continue;
            }

            GX_U3V_DEVICE_INFO &stU3VDevInfo = device_info_ptr.DevInfo.stU3VDevInfo;

            RM_LOG_INFO("    UserDefinedName = {}",
                        (char *) stU3VDevInfo.chUserDefinedName);
            RM_LOG_INFO("    Serial Number   = {}", (char *) stU3VDevInfo.chSerialNumber);
            RM_LOG_INFO("    Device Number   = {}", (char *) stU3VDevInfo.chDeviceVersion);

            if (strcmp(serial_number.c_str(), (char *) stU3VDevInfo.chSerialNumber) != 0)
                continue;

            // 创建句柄
            emStatus = GXOpenDeviceByIndex(i, &g_hDevice);
            if (emStatus != GX_STATUS_SUCCESS) {
                RM_LOG_ERROR("{0} CreateHandle fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
                RM_LOG_ERROR("discoverCamera-> error string: {0}", GetErrorString(emStatus));
                break;
            }


            //Get the type of Bayer conversion. whether is a color camera.
            GX_NODE_ACCESS_MODE emAccessMode;
            emStatus = GXGetNodeAccessMode(g_hDevice, "PixelColorFilter", &emAccessMode);
            if (emStatus != GX_STATUS_SUCCESS) {
                RM_LOG_ERROR("discoverCamera-> GXGetNodeAccessMode error string: {0}", GetErrorString(emStatus));
                break;
            }

            bool g_bColorFilter = ((emAccessMode == GX_NODE_ACCESS_MODE_WO) ||
                                   (emAccessMode == GX_NODE_ACCESS_MODE_RO) ||
                                   (emAccessMode == GX_NODE_ACCESS_MODE_RW)) ? true : false;


            //This app only support color cameras
            if (!g_bColorFilter) {
                RM_LOG_ERROR("discoverCamera-> <This app only support color cameras! App Exit!>");
                break;
            } else {
                GX_ENUM_VALUE emValue;
                emStatus = GXGetEnumValue(g_hDevice, "PixelColorFilter", &emValue);
                if (emStatus != GX_STATUS_SUCCESS) {
                    RM_LOG_ERROR("discoverCamera-> GXGetEnumValue error string: {0}", GetErrorString(emStatus));
                    break;
                }
                g_i64ColorFilter = emValue.stCurValue.nCurValue;
            }


            uint32_t nDSNum = 0;
            emStatus = GXGetDataStreamNumFromDev(g_hDevice, &nDSNum);
            if (emStatus != GX_STATUS_SUCCESS) {
                RM_LOG_ERROR("discoverCamera-> GXGetDataStreamNumFromDev error string: {0}", GetErrorString(emStatus));
                break;
            }

            if (nDSNum < 1) {
                RM_LOG_ERROR("discoverCamera-> Failed to obtain the number of streams");
                break;
            }

            GX_DS_HANDLE phDS = NULL;
            emStatus = GXGetDataStreamHandleFromDev(g_hDevice, 1, &phDS); // TODO 多相机可能需要改nDSIndex
            if (emStatus != GX_STATUS_SUCCESS) {
                RM_LOG_ERROR("discoverCamera-> GXGetDataStreamHandleFromDev error string: {0}",
                             GetErrorString(emStatus));
                break;
            }

            emStatus = GXGetPayLoadSize(phDS, &g_nPayloadSize);
            if (emStatus != GX_STATUS_SUCCESS) {
                RM_LOG_ERROR("discoverCamera-> GXGetPayLoadSize error string: {0}", GetErrorString(emStatus));
                break;
            }

            // 打开设备
            is_find = true;
            break;
        }
        if (!is_find) {
            RM_LOG_ERROR("{0} discoverCamera-> can not find the require camera, continue find camera device...",
                         serial_number_prefix_);
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }
    }
}

void DaHengCameraStream::ConnectCamera() {
    //Set acquisition mode
    emStatus = GXSetEnumValueByString(g_hDevice, "AcquisitionMode", "Continuous");
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("{0} AcquisitionMode Set Continue fail! nRet {1:x}", serial_number_prefix_,
                     (unsigned int) emStatus);
        RM_LOG_ERROR("error string: {0}", GetErrorString(emStatus));
        raise(SIGUSR1);
    }

    //Set trigger mode
    emStatus = GXSetEnumValueByString(g_hDevice, "TriggerMode", "Off");
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("{0} TriggerMode Set Off fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
        RM_LOG_ERROR("error string: {0}", GetErrorString(emStatus));
        raise(SIGUSR1);
    }

    // TODO 断线重连

    // 开始拉流

    //Set buffer quantity of acquisition queue
    uint64_t nBufferNum = ACQ_BUFFER_NUM;
    emStatus = GXSetAcqusitionBufferNumber(g_hDevice, nBufferNum);
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("ConnectCamera-> GXSetAcqusitionBufferNumber error string: {0}", GetErrorString(emStatus));
        return;
    }

    GX_NODE_ACCESS_MODE emStreamTransferSizeIm;
    emStatus = GXGetNodeAccessMode(g_hDevice, "StreamTransferSize", &emStreamTransferSizeIm);
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("ConnectCamera-> GXGetNodeAccessMode error string: {0}", GetErrorString(emStatus));
        return;
    }
    bool bStreamTransferSize = ((emStreamTransferSizeIm == GX_NODE_ACCESS_MODE_RO) ||
                                (emStreamTransferSizeIm == GX_NODE_ACCESS_MODE_WO) ||
                                (emStreamTransferSizeIm == GX_NODE_ACCESS_MODE_RW)) ? true : false;

    if (bStreamTransferSize) {
        //Set size of data transfer block
        emStatus = GXSetIntValue(g_hDevice, "StreamTransferSize", ACQ_TRANSFER_SIZE);
        if (emStatus != GX_STATUS_SUCCESS) {
            RM_LOG_ERROR("ConnectCamera-> GXSetIntValue error string: {0}", GetErrorString(emStatus));
            return;
        }
    }


    GX_NODE_ACCESS_MODE emStreamTransferUrbIm;
    emStatus = GXGetNodeAccessMode(g_hDevice, "StreamTransferNumberUrb", &emStreamTransferUrbIm);
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("ConnectCamera-> GXGetNodeAccessMode error string: {0}", GetErrorString(emStatus));
        return;
    }
    bool bStreamTransferNumberUrb = ((emStreamTransferUrbIm == GX_NODE_ACCESS_MODE_RO) ||
                                     (emStreamTransferUrbIm == GX_NODE_ACCESS_MODE_WO) ||
                                     (emStreamTransferUrbIm == GX_NODE_ACCESS_MODE_RW)) ? true : false;

    if (bStreamTransferNumberUrb) {
        //Set qty. of data transfer block
        emStatus = GXSetIntValue(g_hDevice, "StreamTransferNumberUrb", ACQ_TRANSFER_NUMBER_URB);
        if (emStatus != GX_STATUS_SUCCESS) {
            RM_LOG_ERROR("ConnectCamera-> GXSetIntValue error string: {0}", GetErrorString(emStatus));
            return;
        }
    }

    //Set Balance White Mode : Continuous
    emStatus = GXSetEnumValueByString(g_hDevice, "BalanceWhiteAuto", "Once");
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("ConnectCamera-> GXSetEnumValueByString error string: {0}", GetErrorString(emStatus));
        return;
    }

    //Allocate the memory for pixel format transform
//    std::cout << "g_nPayloadSize:" << g_nPayloadSize << "\n";
    g_pRGBImageBuf = new unsigned char[g_nPayloadSize * 3];
    g_pRaw8Image = new unsigned char[g_nPayloadSize];

    //Device start acquisition
    emStatus = GXStreamOn(g_hDevice);
    if (emStatus != GX_STATUS_SUCCESS) {
        //Release the memory allocated
        RM_LOG_ERROR("ConnectCamera-> GXStreamOn error string: {0}", GetErrorString(emStatus));
        return;
    }
}

void DaHengCameraStream::SetADCBitDepth(int value) {
}

void DaHengCameraStream::SetAcquisitionFrameRate(double value) {
    double set_value = (value < 168.0) ? 168.0 : value;

    emStatus = GXSetFloatValue(g_hDevice, "AcquisitionFrameRate", (float) set_value);
    if (emStatus == GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("{0} set AcquisitionFrameRate fail!", serial_number_prefix_);
    } else {
        RM_LOG_INFO("{0} after change, AcquisitionFrameRate is {1}", serial_number_prefix_, set_value);
        RM_LOG_ERROR("error string: {0}", GetErrorString(emStatus));
    }
}

void DaHengCameraStream::SetResolution(int width, int height) {
    // 设置像素格式
    emStatus = GXSetEnumValue(g_hDevice, "PixelFormat", GX_PIXEL_FORMAT_BAYER_RG8);
    if (GX_STATUS_SUCCESS != emStatus) {
        RM_LOG_ERROR("{0} setPixelFormat fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
    }

    emStatus = GXSetIntValue(g_hDevice, "Width", width);
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("{0} set Width fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
    }

    emStatus = GXSetIntValue(g_hDevice, "Height", height);
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("{0} set Height fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
    }
}

void DaHengCameraStream::SetExposureMode(int value) {
    std::string str_value;
    switch (value) {
        case OFF:
            str_value = "Off";
            break;
        case ONCE:
            str_value = "Once";
            break;
        default:
            str_value = "Continuous";
            break;
    }

    emStatus = GXSetEnumValueByString(g_hDevice, "ExposureAuto", str_value.c_str());
    if (emStatus == GX_STATUS_SUCCESS) {
        RM_LOG_INFO("{0} set ExposureAuto {1} success.", serial_number_prefix_, str_value);
    } else {
        RM_LOG_ERROR("{0} set ExposureAuto {1} fail!", serial_number_prefix_, str_value);
        RM_LOG_ERROR("error string: {0}", GetErrorString(emStatus));
    }
}

void DaHengCameraStream::SetBalanceWhiteMode(int value) {
    std::string str_value;
    switch (value) {
        case OFF:
            str_value = "Off";
            break;
        case ONCE:
            str_value = "Once";
            break;
        default:
            str_value = "Continuous";
            break;
    }

    emStatus = GXSetEnumValueByString(g_hDevice, "BalanceWhiteAuto", str_value.c_str());
    if (emStatus == GX_STATUS_SUCCESS) {
        RM_LOG_INFO("{0} set BalanceWhiteAuto {1} success.", serial_number_prefix_, str_value);
    } else {
        RM_LOG_ERROR("{0} set BalanceWhiteAuto {1} fail!", serial_number_prefix_, str_value);
        RM_LOG_ERROR("error string: {0}", GetErrorString(emStatus));
    }
}

void DaHengCameraStream::SetBrightness(int value) {
    // MV-CS016-10UC 无SetBrightness设置
}

void DaHengCameraStream::SetSharpnessAuto() {
    // MV-CS016-10UC 无SetSharpnessAuto设置
}

void DaHengCameraStream::SetExposureTime(double value, bool add_flag) {
    GX_FLOAT_VALUE node_value;
    memset(&node_value, 0, sizeof(GX_FLOAT_VALUE));
    emStatus = GXGetFloatValue(g_hDevice, "ExposureTime", &node_value);
    if (GX_STATUS_SUCCESS != emStatus) {
        RM_LOG_ERROR("{0} get ExposureTime fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
        return;
    }
    double set_value = node_value.dCurValue;

    if (add_flag) {
        set_value += value;
        if (set_value < 1.0)
            set_value = 1.0;
        else if (set_value > 10000.0)
            set_value = 10000.0;
    } else {
        if (value < 1.0)
            set_value = 1.0;
        else if (value > 10000.0)
            set_value = 10000.0;
        else
            set_value = value;
    }

    emStatus = GXSetFloatValue(g_hDevice, "ExposureTime", set_value);
    if (GX_STATUS_SUCCESS != emStatus) {
        RM_LOG_ERROR("{0} set ExposureTime fail!", serial_number_prefix_);
    } else {
        RM_LOG_INFO("{0} after change, ExposureTime is {1}", serial_number_prefix_, set_value);
    }
}

void DaHengCameraStream::SetGainRaw(double value, bool add_flag) {
    // 关闭自动Gain
    emStatus = GXSetEnumValueByString(g_hDevice, "GainAuto", "Off");
    if (GX_STATUS_SUCCESS == emStatus) {
        RM_LOG_INFO("{0} set GainAuto Off success.", serial_number_prefix_);
    } else {
        RM_LOG_ERROR("{0} set GainAuto Off fail!", serial_number_prefix_);
    }

    // 设置Gain
    GX_FLOAT_VALUE node_value;
    memset(&node_value, 0, sizeof(GX_FLOAT_VALUE));
    emStatus = GXGetFloatValue(g_hDevice, "Gain", &node_value);
    if (GX_STATUS_SUCCESS != emStatus) {
        RM_LOG_ERROR("{0} get Gain fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
        return;
    }
    double set_value = node_value.dCurValue;

    if (add_flag) {
        set_value += value;
        if (set_value < 1.0)
            set_value = 1.0;
        else if (set_value > 32.0)
            set_value = 32.0;
    } else {
        if (value < 0.0)
            set_value = 0.0;
        else if (value > 32.0)
            set_value = 16.0;
        else
            set_value = value;
    }

    emStatus = GXSetFloatValue(g_hDevice, "Gain", (float) set_value);
    if (GX_STATUS_SUCCESS != emStatus) {
        RM_LOG_ERROR("{0} set Gain fail!", serial_number_prefix_);
    } else {
        RM_LOG_INFO("{0} after change, Gain is {1}", serial_number_prefix_, set_value);
    }
}

void DaHengCameraStream::SetGamma(double value, bool add_flag) {
    // MV-CS016-10UC 无Gama设置
}

void DaHengCameraStream::Start() {
    EVOThread::Start();
    thread_ = std::make_unique<std::thread>([this]() {
        PGX_FRAME_BUFFER pFrameBuffer = nullptr;


//        const unsigned int buf_size = sizeof(unsigned char) * width_ * height_ * 3;
//        unsigned char *mat_for_bgr;
//        mat_for_bgr = (unsigned char *) malloc(buf_size);

        int lost_cnt = 0;

        while (is_loop_) {
            std::unique_lock<std::mutex> stop_locker(stop_mutex_);
            if (is_stop_) {
                continue_thread_cv_.wait(stop_locker, [this]() {
                    return !is_stop_ || !is_loop_;
                });
                if (!is_loop_) {
                    break;
                }
            }

            emStatus = GXDQBuf(g_hDevice, &pFrameBuffer, 100); // 使用内部缓存获取一帧图片
            if (emStatus != GX_STATUS_SUCCESS) {
                RM_LOG_ERROR("{0} Get Image fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
                GXStreamOff(g_hDevice); // TODO
                GXStreamOn(g_hDevice); // TODO
                stop_locker.unlock();
                if (lost_cnt >= 10) {
                    raise(SIGUSR1);
                }
                ++lost_cnt;
                std::this_thread::sleep_for(std::chrono::milliseconds(200));
                continue;
            }
            stop_locker.unlock();
//            printf("Get Image Buffer: Width[%d], Height[%d], FrameNum[%d]\n",
//                   frame.stFrameInfo.nWidth, frame.stFrameInfo.nHeight, frame.stFrameInfo.nFrameNum);
            lost_cnt = 0;


            if (pFrameBuffer->nStatus != GX_FRAME_STATUS_SUCCESS) {
                RM_LOG_ERROR("<Abnormal Acquisition: Exception code: {1}>", serial_number_prefix_,
                             pFrameBuffer->nStatus);
                continue;
            }

            // Convert to the RGB image

// GX_PIXEL_FORMAT_BGR8
//            emStatus = DxImageFormatConvert(g_hDevice,
//                                            pFrameBuffer->pImgBuf,
//                                            pFrameBuffer->nImgSize,
//                                            mat_for_bgr,
//                                            buf_size,
//                                            pFrameBuffer->nPixelFormat,
//                                            pFrameBuffer->nWidth, // width_
//                                            pFrameBuffer->nHeight, // height_
//                                            false
//                                            );
//            if (emStatus != GX_STATUS_SUCCESS) {
//                RM_LOG_ERROR("{0} Convert Pixel Type fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
//                continue;
//            }
            // Convert to the RGB image
            VxInt32 emDXStatus = DxRaw8toRGB24Ex((unsigned char *) pFrameBuffer->pImgBuf, g_pRGBImageBuf,
                                                 pFrameBuffer->nWidth, pFrameBuffer->nHeight,
                                                 RAW2RGB_NEIGHBOUR, DX_PIXEL_COLOR_FILTER(g_i64ColorFilter), false,
                                                 DX_ORDER_BGR);
            if (emDXStatus != DX_OK) {
                RM_LOG_ERROR("{0} DxRaw8toRGB24 Failed, Error Code:  {1:x}", serial_number_prefix_,
                             (unsigned int) emDXStatus);
                continue;
            }

            origin_image_ = cv::Mat((int) pFrameBuffer->nHeight, (int) pFrameBuffer->nWidth, CV_8UC3,
                                    (void *) g_pRGBImageBuf);
            {
                std::unique_lock<std::shared_mutex> lk(mat_image_mutex_);
                origin_image_.copyTo(mat_image_.image);
                mat_image_.time_stamp = std::chrono::steady_clock::now();
            }
            CalculateFrameFPS();

            emStatus = GXQBuf(g_hDevice, pFrameBuffer); // 释放图像缓存
            if (emStatus != GX_STATUS_SUCCESS) {
                RM_LOG_ERROR("{0} Free Image Buffer fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
                continue;
            }
        }
//        free(mat_for_bgr);
        GXQBuf(g_hDevice, pFrameBuffer); // 释放图像缓存
    });
}

void DaHengCameraStream::StopGrabbing() {
    std::unique_lock<std::mutex> stop_locker(stop_mutex_);
    if (is_stop_) return;
    is_stop_ = true;

    emStatus = GXStreamOff(g_hDevice); // 停止采集图像
    if (GX_STATUS_SUCCESS != emStatus) {
        RM_LOG_ERROR("{0} stop-> StopGrabbing fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
    } else {
        RM_LOG_INFO("{0} stop-> wait to grabbing.", serial_number_prefix_);
    }
}

void DaHengCameraStream::ContinueGrabbing() {
    std::unique_lock<std::mutex> stop_locker(stop_mutex_);
    if (!is_stop_) return;
    is_stop_ = false;

    emStatus = GXStreamOn(g_hDevice); // 开始采集图像
    if (GX_STATUS_SUCCESS != emStatus) {
        RM_LOG_ERROR("{0} continue-> StartGrabbing fail! nRet {1:x}", serial_number_prefix_, (unsigned int) emStatus);
    } else {
        RM_LOG_INFO("{0} continue-> continue grabbing.", serial_number_prefix_);
    }

    continue_thread_cv_.notify_all();
}

void DaHengCameraStream::CloseCamera() {
    {
        std::lock_guard<std::mutex> stop_locker(stop_mutex_);
        is_stop_ = false;
        is_loop_ = false;
        continue_thread_cv_.notify_all();
    }
    Destroy(); // 销毁拉流线程

    //Device stop acquisition
    emStatus = GXStreamOff(g_hDevice);
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("GXStreamOff error string: {0}", GetErrorString(emStatus));
    }

    //Release resources
    //Release the memory allocated
    if (g_pRaw8Image != NULL) {
        delete[] g_pRaw8Image;
        g_pRaw8Image = NULL;
    }
    if (g_pRGBImageBuf != NULL) {
        delete[] g_pRGBImageBuf;
        g_pRGBImageBuf = NULL;
    }

    //Close device
    emStatus = GXCloseDevice(g_hDevice);
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("GXCloseDevice error string: {0}", GetErrorString(emStatus));
    }
    g_hDevice = nullptr;

    //Release libary
    emStatus = GXCloseLib();
    if (emStatus != GX_STATUS_SUCCESS) {
        RM_LOG_ERROR("GXCloseLib error string: {0}", GetErrorString(emStatus));
    }

    RM_LOG_INFO("{0} CloseCamera-> cancel thread successfully.", serial_number_prefix_);
}

void DaHengCameraStream::ReconnectCameraInit() {
    frame_count_ = 0;
    last_time_stamp_ = std::chrono::steady_clock::now();
}

}