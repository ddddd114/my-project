//
// Created by Champrin on 2023/8/2.
//

#include "camera_stream/camera_stream.h"

namespace camera_stream {

CameraStream::CameraStream(const std::string &serial_number) {
    serial_number_prefix_ = "[" + serial_number + "]";
    thread_prefix_ = serial_number_prefix_ + "camera_stream";
}

void CameraStream::SetCameraParasFromFile(double exposure, double gain, double gamma) {
    SetExposureTime(exposure, false);
    SetGainRaw(gain, false);
    SetGamma(gamma, false);
}

}