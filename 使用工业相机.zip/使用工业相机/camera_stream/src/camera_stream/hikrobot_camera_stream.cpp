//
// Created by Champrin on 2023/8/2.
//

#include "camera_stream/hikrobot_camera_stream.h"

#include <csignal>

namespace camera_stream {

namespace {
constexpr unsigned int kBayerCvtQualityHamilton = 2U;
}

HIKROBOTCameraStream::HIKROBOTCameraStream(const std::string &serial_number) : CameraStream(serial_number) {
    // 发现相机
    DiscoverCamera(serial_number);

    // 设置相机参数
    SetADCBitDepth(8); // 设置景深
    SetAcquisitionFrameRate(250.0); // 设置相机最大帧率
    SetExposureMode(OFF); // 关闭相机内部的自动曝光
    SetBalanceWhiteMode(CONTINUOUS); // 打开自动白平衡
    RM_LOG_INFO("{0} connectCamera-> modify camera init successful.", serial_number_prefix_);

    // 连接相机
    ConnectCamera();

    // 设置图像参数
    MVCC_INTVALUE_EX height_node; // 取得相机分辨率的 height 属性节点
    memset(&height_node, 0, sizeof(MVCC_INTVALUE_EX));
    MV_CC_GetIntValueEx(camera_handle_, "Height", &height_node);

    MVCC_INTVALUE_EX width_node; // 取得相机分辨率的 width 属性节点
    memset(&width_node, 0, sizeof(MVCC_INTVALUE_EX));
    MV_CC_GetIntValueEx(camera_handle_, "Width", &width_node);

    mat_image_.image = cv::Mat(static_cast<int>(height_node.nCurValue), static_cast<int>(width_node.nCurValue), CV_8UC3);
    mat_size_ = {static_cast<float>(width_node.nCurValue), static_cast<float>(height_node.nCurValue)};

    height_ = static_cast<unsigned short>(height_node.nCurValue);
    width_ = static_cast<unsigned short>(width_node.nCurValue);

    // 开始拉流线程
    Start();
    std::this_thread::sleep_for(std::chrono::milliseconds(800));

    RM_LOG_INFO("{0} connectCamera-> calculate ready.", serial_number_prefix_);
}

void HIKROBOTCameraStream::DiscoverCamera(const std::string &serial_number) {
    // 打开设备
    MV_CC_DEVICE_INFO_LIST stDeviceList;

    int loop_cnt = 0;
    bool is_find = false;
    while (!is_find) {
        if(loop_cnt >= 25){
            raise(SIGUSR1);
        }
        memset(&stDeviceList, 0, sizeof(MV_CC_DEVICE_INFO_LIST));
        nRet_ = MV_CC_EnumDevices(MV_GIGE_DEVICE | MV_USB_DEVICE, &stDeviceList); // 枚举设备
        if (MV_OK != nRet_) { // 发现设备失败
            RM_LOG_ERROR("{0} discoverCamera-> discover device fail, continue find camera device...", serial_number_prefix_);
            ++loop_cnt;
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }

        if (stDeviceList.nDeviceNum == 0) { // 相机设备为空
            RM_LOG_ERROR("{0} discoverCamera-> no camera device find, continue find camera device...", serial_number_prefix_);
            ++loop_cnt;
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }

        MV_CC_DEVICE_INFO *device_info_ptr;
        for (int i = 0; i < stDeviceList.nDeviceNum; ++i) {
            device_info_ptr = stDeviceList.pDeviceInfo[i];

            RM_LOG_INFO("    UserDefinedName = {}", (char *) device_info_ptr->SpecialInfo.stUsb3VInfo.chUserDefinedName);
            RM_LOG_INFO("    Serial Number   = {}", (char *) device_info_ptr->SpecialInfo.stUsb3VInfo.chSerialNumber);
            RM_LOG_INFO("    Device Number   = {}", device_info_ptr->SpecialInfo.stUsb3VInfo.nDeviceNumber);

            if (strcmp(serial_number.c_str(), (char *) device_info_ptr->SpecialInfo.stUsb3VInfo.chSerialNumber) != 0)
                continue;

            // 创建句柄
            nRet_ = MV_CC_CreateHandle(&camera_handle_, stDeviceList.pDeviceInfo[i]);
            if (MV_OK != nRet_) {
                RM_LOG_ERROR("{0} CreateHandle fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
                break;
            }

            // 打开设备
            nRet_ = MV_CC_OpenDevice(camera_handle_);
            if (MV_OK == nRet_) {
                RM_LOG_INFO("{0} open device successful.", serial_number_prefix_);
                is_find = true;
            } else {
                RM_LOG_ERROR("{0} open device fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
            }
            break;
        }
        if (!is_find) {
            RM_LOG_ERROR("{0} discoverCamera-> can not find the require camera, continue find camera device...", serial_number_prefix_);
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }
    }
}

void HIKROBOTCameraStream::ConnectCamera() {
    // 设置触发模式为off
    nRet_ = MV_CC_SetEnumValue(camera_handle_, "TriggerMode", MV_TRIGGER_MODE_OFF);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} TriggerMode Set Off fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
        raise(SIGUSR1);
    }

    // 设置采集模式为连续采集
    nRet_ = MV_CC_SetEnumValue(camera_handle_, "AcquisitionMode", MV_ACQ_MODE_CONTINUOUS);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} AcquisitionMode Set Continue fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
        raise(SIGUSR1);
    }

    nRet_ = MV_CC_SetBayerCvtQuality(camera_handle_, kBayerCvtQualityHamilton);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} SetBayerCvtQuality Hamilton fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
        raise(SIGUSR1);
    } else {
        RM_LOG_INFO("{0} Bayer convert quality set to Hamilton.", serial_number_prefix_);
    }

    // TODO 断线重连

    // 开始拉流
    nRet_ = MV_CC_StartGrabbing(camera_handle_);
    if (MV_OK == nRet_) {
        RM_LOG_INFO("{0} StartGrabbing successful.", serial_number_prefix_);
    } else {
        RM_LOG_ERROR("{0} StartGrabbing fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
        raise(SIGUSR1);
    }
}

void HIKROBOTCameraStream::SetADCBitDepth(int value) {
    std::string str_value = (value == 12) ? "ADCBitDepth_12" : "ADCBitDepth_8";
    nRet_ = MV_CC_SetEnumValueByString(camera_handle_, "ADCBitDepth", str_value.c_str());
    if (MV_OK == nRet_) {
        RM_LOG_INFO("{0} set ADCBitDepth {1} success.", serial_number_prefix_, str_value);
    } else {
        RM_LOG_ERROR("{0} set ADCBitDepth {1} fail!", serial_number_prefix_, str_value);
    }
}

void HIKROBOTCameraStream::SetAcquisitionFrameRate(double value) {
    double set_value = (value < 250.0) ? 250.0 : value;

    nRet_ = MV_CC_SetFloatValue(camera_handle_, "AcquisitionFrameRate", (float) set_value);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} set AcquisitionFrameRate fail!", serial_number_prefix_);
    } else {
        RM_LOG_INFO("{0} after change, AcquisitionFrameRate is {1}", serial_number_prefix_, set_value);
    }
}

void HIKROBOTCameraStream::SetResolution(int width, int height) {
    // 设置像素格式
    nRet_ = MV_CC_SetEnumValue(camera_handle_, "PixelFormat", PixelType_Gvsp_BayerRG8);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} setPixelFormat fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
    }

    nRet_ = MV_CC_SetIntValueEx(camera_handle_, "Width", width);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} set Width fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
    }

    nRet_ = MV_CC_SetIntValueEx(camera_handle_, "Height", height);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} set Height fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
    }
}

void HIKROBOTCameraStream::SetExposureMode(int value) {
    std::string str_value;
    switch (value) {
        case OFF:
            str_value = "Off";
            break;
        case ONCE:
            str_value = "Once";
            break;
        default:
            str_value = "Continuous";
            break;
    }

    nRet_ = MV_CC_SetEnumValueByString(camera_handle_, "ExposureAuto", str_value.c_str());
    if (MV_OK == nRet_) {
        RM_LOG_INFO("{0} set ExposureAuto {1} success.", serial_number_prefix_, str_value);
    } else {
        RM_LOG_ERROR("{0} set ExposureAuto {1} fail!", serial_number_prefix_, str_value);
    }
}

void HIKROBOTCameraStream::SetBalanceWhiteMode(int value) {
    std::string str_value;
    switch (value) {
        case OFF:
            str_value = "Off";
            break;
        case ONCE:
            str_value = "Once";
            break;
        default:
            str_value = "Continuous";
            break;
    }

    nRet_ = MV_CC_SetEnumValueByString(camera_handle_, "BalanceWhiteAuto", str_value.c_str());
    if (MV_OK == nRet_) {
        RM_LOG_INFO("{0} set BalanceWhiteAuto {1} success.", serial_number_prefix_, str_value);
    } else {
        RM_LOG_ERROR("{0} set BalanceWhiteAuto {1} fail!", serial_number_prefix_, str_value);
    }
}

void HIKROBOTCameraStream::SetBrightness(int value) {
    // MV-CS016-10UC 无SetBrightness设置
}

void HIKROBOTCameraStream::SetSharpnessAuto() {
    // MV-CS016-10UC 无SetSharpnessAuto设置
}

void HIKROBOTCameraStream::SetExposureTime(double value, bool add_flag) {
    MVCC_FLOATVALUE node_value;
    memset(&node_value, 0, sizeof(MVCC_FLOATVALUE));
    nRet_ = MV_CC_GetFloatValue(camera_handle_, "ExposureTime", &node_value);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} get ExposureTime fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
        return;
    }
    double set_value = node_value.fCurValue;

    if (add_flag) {
        set_value += value;
        if (set_value < 1.0)
            set_value = 1.0;
        else if (set_value > 10000.0)
            set_value = 10000.0;
    } else {
        if (value < 1.0)
            set_value = 1.0;
        else if (value > 10000.0)
            set_value = 10000.0;
        else
            set_value = value;
    }

    nRet_ = MV_CC_SetFloatValue(camera_handle_, "ExposureTime", (float) set_value);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} set ExposureTime fail!", serial_number_prefix_);
    } else {
        RM_LOG_INFO("{0} after change, ExposureTime is {1}", serial_number_prefix_, set_value);
    }
}

void HIKROBOTCameraStream::SetGainRaw(double value, bool add_flag) {
    // 关闭自动Gain
    nRet_ = MV_CC_SetEnumValueByString(camera_handle_, "GainAuto", "Off");
    if (MV_OK == nRet_) {
        RM_LOG_INFO("{0} set GainAuto Off success.", serial_number_prefix_);
    } else {
        RM_LOG_ERROR("{0} set GainAuto Off fail!", serial_number_prefix_);
    }

    // 设置Gain
    MVCC_FLOATVALUE node_value;
    memset(&node_value, 0, sizeof(MVCC_FLOATVALUE));
    nRet_ = MV_CC_GetFloatValue(camera_handle_, "Gain", &node_value);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} get Gain fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
        return;
    }
    double set_value = node_value.fCurValue;

    if (add_flag) {
        set_value += value;
        if (set_value < 1.0)
            set_value = 1.0;
        else if (set_value > 32.0)
            set_value = 32.0;
    } else {
        if (value < 0.0)
            set_value = 0.0;
        else if (value > 32.0)
            set_value = 16.0;
        else
            set_value = value;
    }

    nRet_ = MV_CC_SetFloatValue(camera_handle_, "Gain", (float) set_value);
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} set Gain fail!", serial_number_prefix_);
    } else {
        RM_LOG_INFO("{0} after change, Gain is {1}", serial_number_prefix_, set_value);
    }
}

void HIKROBOTCameraStream::SetGamma(double value, bool add_flag) {
    // MV-CS016-10UC 无Gama设置
}

void HIKROBOTCameraStream::Start() {
    EVOThread::Start();
    thread_ = std::make_unique<std::thread>([this]() {
        MV_FRAME_OUT frame = {nullptr};

        const unsigned int buf_size = sizeof(unsigned char) * width_ * height_ * 3;
        unsigned char *mat_for_bgr;
        mat_for_bgr = (unsigned char *) malloc(buf_size);
        MV_CC_PIXEL_CONVERT_PARAM convert_param{
                .nWidth = width_,
                .nHeight = height_,
                .enSrcPixelType = PixelType_Gvsp_BayerRG8,
                .enDstPixelType = PixelType_Gvsp_BGR8_Packed,
                .pDstBuffer = mat_for_bgr,
                .nDstBufferSize = buf_size,
        };

        int lost_cnt = 0;

        while (is_loop_) {
            std::unique_lock<std::mutex> stop_locker(stop_mutex_);
            if (is_stop_) {
                continue_thread_cv_.wait(stop_locker, [this]() {
                    return !is_stop_ || !is_loop_;
                });
                if (!is_loop_) {
                    break;
                }
            }

            nRet_ = MV_CC_GetImageBuffer(camera_handle_, &frame, 100); // 使用内部缓存获取一帧图片
            if (nRet_ != MV_OK) {
                RM_LOG_ERROR("{0} Get Image fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
                MV_CC_StopGrabbing(camera_handle_);
                MV_CC_StartGrabbing(camera_handle_);
                stop_locker.unlock();
                if (lost_cnt >= 10) {
                    raise(SIGUSR1);
                }
                ++lost_cnt;
                std::this_thread::sleep_for(std::chrono::milliseconds(200));
                continue;
            }
            stop_locker.unlock();
//            printf("Get Image Buffer: Width[%d], Height[%d], FrameNum[%d]\n",
//                   frame.stFrameInfo.nWidth, frame.stFrameInfo.nHeight, frame.stFrameInfo.nFrameNum);
            lost_cnt = 0;

            convert_param.pSrcData = frame.pBufAddr;
            convert_param.nSrcDataLen = frame.stFrameInfo.nFrameLen;
            nRet_ = MV_CC_ConvertPixelType(camera_handle_, &convert_param);
            if (nRet_ != MV_OK) {
                RM_LOG_ERROR("{0} Convert Pixel Type fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
                continue;
            }

            origin_image_ = cv::Mat((int) frame.stFrameInfo.nHeight, (int) frame.stFrameInfo.nWidth, CV_8UC3,
                                    (void *) mat_for_bgr);
            {
                std::unique_lock<std::shared_mutex> lk(mat_image_mutex_);
                origin_image_.copyTo(mat_image_.image);
                mat_image_.time_stamp = std::chrono::steady_clock::now();
            }
            CalculateFrameFPS();

            nRet_ = MV_CC_FreeImageBuffer(camera_handle_, &frame); // 释放图像缓存
            if (nRet_ != MV_OK) {
                RM_LOG_ERROR("{0} Free Image Buffer fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
                continue;
            }
        }
        free(mat_for_bgr);
        MV_CC_FreeImageBuffer(camera_handle_, &frame); // 释放图像缓存
    });
}

void HIKROBOTCameraStream::StopGrabbing() {
    std::unique_lock<std::mutex> stop_locker(stop_mutex_);
    if (is_stop_) return;
    is_stop_ = true;

    nRet_ = MV_CC_StopGrabbing(camera_handle_); // 停止采集图像
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} stop-> StopGrabbing fail! nRet {1:x}", serial_number_prefix_, (unsigned int) nRet_);
    } else {
        RM_LOG_INFO("{0} stop-> wait to grabbing.", serial_number_prefix_);
    }
}

void HIKROBOTCameraStream::ContinueGrabbing() {
    std::unique_lock<std::mutex> stop_locker(stop_mutex_);
    if (!is_stop_) return;
    is_stop_ = false;

    nRet_ = MV_CC_StartGrabbing(camera_handle_); // 开始采集图像
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} continue-> StartGrabbing fail! nRet {1:x}", serial_number_prefix_, (unsigned int) nRet_);
    } else {
        RM_LOG_INFO("{0} continue-> continue grabbing.", serial_number_prefix_);
    }

    continue_thread_cv_.notify_all();
}

void HIKROBOTCameraStream::CloseCamera() {
    {
        std::lock_guard<std::mutex> stop_locker(stop_mutex_);
        is_stop_ = false;
        is_loop_ = false;
        continue_thread_cv_.notify_all();
    }
    Destroy(); // 销毁拉流线程

    nRet_ = MV_CC_StopGrabbing(camera_handle_); // 停止采集图像
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} StopGrabbing fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
        return;
    }

    nRet_ = MV_CC_CloseDevice(camera_handle_); // 关闭设备
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} CloseDevice fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
        return;
    }

    nRet_ = MV_CC_DestroyHandle(camera_handle_); // 销毁相机设备句柄
    if (MV_OK != nRet_) {
        RM_LOG_ERROR("{0} DestroyHandle fail! nRet {1:x}", serial_number_prefix_, (unsigned int)nRet_);
        return;
    }
    camera_handle_ = nullptr;

    RM_LOG_INFO("{0} CloseCamera-> cancel thread successfully.", serial_number_prefix_);
}

void HIKROBOTCameraStream::ReconnectCameraInit() {
    frame_count_ = 0;
    last_time_stamp_ = std::chrono::steady_clock::now();
}

}