//
// Created by Champrin on 2023/10/29.
//

#include "camera_stream/video_stream.h"

namespace camera_stream {

VideoStream::VideoStream(const std::string &serial_number) : CameraStream(serial_number) {
    video_capture_uptr_ = std::make_unique<cv::VideoCapture>(serial_number);
    if (!video_capture_uptr_->isOpened()) {
        // 如果视频不能正常打开则返回
        RM_LOG_INFO("{} Video-> No video", serial_number_prefix_);
        exit(-1);
    }

    auto width_ = video_capture_uptr_->get(cv::CAP_PROP_FRAME_WIDTH);
    auto height_ = video_capture_uptr_->get(cv::CAP_PROP_FRAME_HEIGHT);
    mat_image_.image = cv::Mat(static_cast<int>(height_), static_cast<int>(width_), CV_8UC3);
    mat_size_ = {static_cast<float>(width_), static_cast<float>(height_)};

    fps_ = video_capture_uptr_->get(cv::CAP_PROP_FPS);
    RM_LOG_INFO("{0} Video-> calculate ready. width={1} height={2} fps={3}", serial_number_prefix_, width_, height_,
                fps_);
}

utils::CameraFrame VideoStream::mat_image() {
    {
        std::unique_lock<std::shared_mutex> lk(mat_image_mutex_);
        video_capture_uptr_->read(mat_image_.image);
        mat_image_.time_stamp = std::chrono::steady_clock::now();
    }
    if (mat_image_.image.empty()) {
        RM_LOG_INFO("{} Video-> frame empty", serial_number_prefix_);
        exit(-1);
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(1.0 / fps_ * 1000.)));
    return mat_image_;
}

void VideoStream::CloseCamera() {
    is_loop_ = false;
    video_capture_uptr_->release();

    RM_LOG_INFO("{} Video-> cancel thread successfully", serial_number_prefix_);
}

}


