//
// Created by champrin on 9/7/25.
//

#ifndef EVO_RMCV_DAHENGCAMERASTREAM_H_
#define EVO_RMCV_DAHENGCAMERASTREAM_H_

#include "camera_stream/camera_stream.h"
#include "sdk/daheng/DxImageProc.h"
#include "sdk/daheng/GxIAPI.h"

namespace camera_stream {

class DaHengCameraStream : public CameraStream {
public:
    explicit DaHengCameraStream(const std::string &serial_number);

    DaHengCameraStream() = delete;

    ~DaHengCameraStream() = default;

    void SetADCBitDepth(int value) final;

    void SetAcquisitionFrameRate(double value) final;

    void SetResolution(int width, int height) final;

    void SetExposureMode(int value) final; // value -1:Off 0:Once default:Continuous

    void SetBalanceWhiteMode(int value) final;  // value -1:Off 0:Once default:Continuous

    void SetBrightness(int value) final;

    void SetSharpnessAuto() final;

    void SetExposureTime(double value, bool add_flag) final;

    void SetGainRaw(double value, bool add_flag) final;

    void SetGamma(double value, bool add_flag) final;

    void Start() final;

    void CloseCamera() final;

    void StopGrabbing() final;

    void ContinueGrabbing() final;

protected:
    void DiscoverCamera(const std::string &serial_number) final;

    void ConnectCamera() final;

    void ReconnectCameraInit() final;

private:
    GX_STATUS emStatus = GX_STATUS_SUCCESS;
    GX_DEV_HANDLE g_hDevice = nullptr; // 相机设备句柄
    int64_t g_i64ColorFilter = GX_COLOR_FILTER_NONE;    ///< Color filter of device

    unsigned char* g_pRGBImageBuf = NULL;               ///< Memory for RAW8toRGB24
    unsigned char* g_pRaw8Image = NULL;                 ///< Memory for RAW16toRAW8

    uint32_t g_nPayloadSize = 0;                         ///< Payload size
    unsigned short height_, width_;
};

}

#endif //EVO_RMCV_DAHENGCAMERASTREAM_H_
