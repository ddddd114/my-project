//
// Created by Champrin on 2023/8/1.
//

#ifndef EVO_RMCV_SAVE_VIDEO_H_
#define EVO_RMCV_SAVE_VIDEO_H_

#include <thread>
#include <atomic>

#include <opencv2/opencv.hpp>
#include "utils/rm_define.h"

namespace camera_stream {

class SaveVideo {
public:
    using GetImageFunc = std::function<utils::CameraFrame()>;
    /**
     *
     * @param camera_name 保存视频地址
     * @param camera_stream_sptr
     */
    SaveVideo(const std::string& camera_name, const cv::Size2f &image_size, const GetImageFunc &get_image_func);

    ~SaveVideo() = default;

    void Destroy();

private:
    GetImageFunc get_image_func_;

    std::atomic<bool> is_loop_;
    std::thread save_video_thread_;

    std::string save_video_name_;
    std::unique_ptr<cv::VideoWriter> video_writer_uptr = nullptr;
};

}

#endif //EVO_RMCV_SAVE_VIDEO_H_