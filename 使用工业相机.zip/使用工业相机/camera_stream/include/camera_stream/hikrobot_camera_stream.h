//
// Created by Champrin on 2023/8/2.
//

#ifndef EVO_RMCV_HIKROBOT_CAMERA_STREAM_H_
#define EVO_RMCV_HIKROBOT_CAMERA_STREAM_H_

#include "camera_stream/camera_stream.h"
#include "sdk/hikrobot/MvCameraControl.h"

namespace camera_stream {

class HIKROBOTCameraStream : public CameraStream {
public:
    explicit HIKROBOTCameraStream(const std::string &serial_number);

    HIKROBOTCameraStream() = delete;

    ~HIKROBOTCameraStream() = default;

    void SetADCBitDepth(int value) final;

    void SetAcquisitionFrameRate(double value) final;

    void SetResolution(int width, int height) final;

    void SetExposureMode(int value) final; // value -1:Off 0:Once default:Continuous

    void SetBalanceWhiteMode(int value) final;  // value -1:Off 0:Once default:Continuous

    void SetBrightness(int value) final;

    void SetSharpnessAuto() final;

    void SetExposureTime(double value, bool add_flag) final;

    void SetGainRaw(double value, bool add_flag) final;

    void SetGamma(double value, bool add_flag) final;

    void Start() final;

    void CloseCamera() final;

    void StopGrabbing() final;

    void ContinueGrabbing() final;

protected:
    void DiscoverCamera(const std::string &serial_number) final;

    void ConnectCamera() final;

    void ReconnectCameraInit() final;

private:
    int nRet_ = MV_OK;
    void *camera_handle_ = nullptr; // 相机设备句柄

    unsigned short height_, width_;
};

}

#endif //EVO_RMCV_HIKROBOT_CAMERA_STREAM_H_