//
// Created by Champrin on 2023/8/2.
//

#ifndef EVO_RMCV_CAMERA_STREAM_H_
#define EVO_RMCV_CAMERA_STREAM_H_

#include <thread>
#include <atomic>
#include <mutex>
#include <condition_variable>

#include <opencv2/opencv.hpp>

#include "utils/evo_thread.h"
#include "utils/rm_define.h"

namespace camera_stream {

class CameraStream : public utils::EVOThread{
public:
    typedef enum {
        OFF = -1,        //关闭
        ONCE = 0,       //单次
        CONTINUOUS = 1  //自动
    } CameraModeSet;

    explicit CameraStream(const std::string &serial_number);

    CameraStream() = delete;

    ~CameraStream() = default;

    void SetCameraParasFromFile(double exposure, double gain, double gamma);

    virtual void SetADCBitDepth(int value){};

    virtual void SetAcquisitionFrameRate(double value){};

    virtual void SetResolution(int width, int height){};

    virtual void SetExposureMode(int value){};

    virtual void SetBalanceWhiteMode(int value){};

    virtual void SetBrightness(int value){};

    virtual void SetSharpnessAuto(){};

    virtual void SetExposureTime(double value, bool add_flag){};

    virtual void SetGainRaw(double value, bool add_flag){};

    virtual void SetGamma(double value, bool add_flag){};

    virtual void StopGrabbing() {}

    virtual void ContinueGrabbing() {}

    virtual utils::CameraFrame mat_image() {
        std::shared_lock<std::shared_mutex> mat_image_locker(mat_image_mutex_);
        return mat_image_;
    }

    cv::Size2f mat_size() const {
        return mat_size_;
    }

    /**
     * 获取帧率
     * @return
     */
    double GetFrameFps() const {
        return frame_fps_;
    }

    /**
     * 关闭相机连接外部接口，在需要程序运行结束时使用
     */
    virtual void CloseCamera(){};

protected:
    virtual void DiscoverCamera(const std::string &serial_number){};

    virtual void ConnectCamera(){};

    /**
     * 重连相机后要执行的操作
     * 比如：帧率计算相关参数重置，软触发设置重设等
     */
    virtual void ReconnectCameraInit(){};

    std::string serial_number_prefix_;

    cv::Mat origin_image_; // 原始拉流图像
    std::shared_mutex mat_image_mutex_;
    utils::CameraFrame mat_image_; // 格式转换后的拉流图像
    cv::Size2f mat_size_;

    std::atomic<bool> is_stop_ {false};
    std::condition_variable continue_thread_cv_;
    std::mutex stop_mutex_;
};

}

#endif //EVO_RMCV_CAMERA_STREAM_H_