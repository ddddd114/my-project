//
// Created by Champrin on 2023/10/29.
//

#ifndef EVO_RMCV_VIDEO_STREAM_H_
#define EVO_RMCV_VIDEO_STREAM_H_

#include "camera_stream/camera_stream.h"

namespace camera_stream {

class VideoStream : public CameraStream {
public:
    explicit VideoStream(const std::string &serial_number);

    VideoStream() = delete;

    ~VideoStream() = default;

    void CloseCamera() final;

    utils::CameraFrame mat_image() final;

private:
    std::unique_ptr<cv::VideoCapture> video_capture_uptr_;
    double fps_;
};

}

#endif //EVO_RMCV_VIDEO_STREAM_H_
